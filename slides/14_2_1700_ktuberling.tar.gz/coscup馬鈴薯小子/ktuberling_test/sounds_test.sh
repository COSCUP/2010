#!/bin/sh
echo "本程式會協助您安裝正體中文音效至potato guy"
sudo cp -r ./sounds /usr/share/kde4/apps/ktuberling/

