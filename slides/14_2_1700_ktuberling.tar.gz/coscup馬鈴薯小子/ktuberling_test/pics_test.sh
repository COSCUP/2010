#!/bin/sh
echo "本程式會協助您安裝Rokya's test主題至potato guy"
sudo cp -r ./pics /usr/share/kde4/apps/ktuberling/

